<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biblioteca</title>
</head>
<body>
    <h1>Bem vindo ao Sistema Biblioteca</h1>
    <p>Aqui você pode cadrastrar bibliotecas, livros, reservas, atendentes e alunos, também pode ver
     quem ou que está cadrastado, assim como modificar o que já está cadrastado. </p>  
    </body>
  </html>
